import numpy as np
import time

def compute_l2_distance(x, centroid):
    # Compute the difference, following by raising to power 2 and summing
    dist = ((x - centroid) ** 2).sum(axis=x.ndim - 1)

    return dist


def get_closest_centroid(x, centroids):
    # Loop over each centroid and compute the distance from data point.
    dist = compute_l2_distance(x, centroids)
    print(dist ** 0.5)
    return 0
    # Get the index of the centroid with the smallest distance to the data point
    closest_centroid_index = np.argmin(dist, axis=1)

    return closest_centroid_index



# TODO: IMPLEMENT IN POCHADE.PY

def test_3d():

    a = np.arange(12)
    a = a.reshape((2, 2, 3))

    b = np.arange(6)
    b = b.reshape((1, 2, 3))

    # newa = a[:, np.newaxis, :, :]
    # newb = b[np.newaxis, :, :, :]

    #
    print(a)
    print("---------------")
    print(b)
    print("---------------")

    newa = a[:, np.newaxis, :]
    newb = b[np.newaxis, :, :]
    norm = np.linalg.norm(newa-newb,axis=3)
    print(norm)


def test_2d():
    a = np.arange(12)
    a = a.reshape((2, 2, 3))

    b = np.arange(6)
    b = b.reshape((1, 2, 3))